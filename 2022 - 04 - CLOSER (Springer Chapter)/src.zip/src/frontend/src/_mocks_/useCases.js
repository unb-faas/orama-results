import faker from 'faker';

const useCases = [{
  id: 1,
  name: "FaaS as backend for DBaaS",
  acronym: "F2DB",
  active: 1,
},
{
  id: 2,
  name: "FaaS as backend for Object Storage",
  acronym: "F2OS",
  active: 1,
},
];

export default useCases;
