export { default as RepetitionAvgChart } from './RepetitionAvgChart'
